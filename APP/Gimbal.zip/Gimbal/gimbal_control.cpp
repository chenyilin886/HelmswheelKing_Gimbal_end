#include "gimbal_control.hpp"
#include "gimbal_c_api.h"
#include <cmath>

BSP::Motor::DM::J4310<2> dm_motor(0x00, {0x01, 0x02}, {0x01, 0x02});
BSP::REMOTE_CONTROL::RemoteController dr16;

ALG::PID::PID yaw_angle_pid(15.0f, 0.01f, 0.5f, 30.0f, 5.0f, 3.0f);
ALG::PID::PID pitch_angle_pid(18.0f, 0.01f, 0.8f, 30.0f, 5.0f, 3.0f);
ALG::PID::PID yaw_speed_pid(0.5f, 0.01f, 0.01f, 3.0f, 1.0f, 5.0f);
ALG::PID::PID pitch_speed_pid(0.5f, 0.01f, 0.01f, 3.0f, 1.0f, 5.0f);

float target_yaw_rad = 0.0f;
float target_pitch_rad = 0.0f;

static float yaw_offset = 0.0f;
static float pitch_offset = 0.0f;
static bool encoder_initialized = false;
static bool motors_enabled = false;
static uint8_t dbus_rx_buffer[Gimbal::DBUS_BUF_SIZE];

static float Clamp(float v, float lo, float hi)
{
    if (v < lo) return lo;
    if (v > hi) return hi;
    return v;
}

namespace Gimbal
{

void Init()
{
    HAL::CAN::ICanDevice &can1 = HAL::CAN::get_can_bus_instance().get_can1();
    can1.register_rx_callback([](const HAL::CAN::Frame &frame)
    {
        dm_motor.Parse(frame);

        if (!encoder_initialized
            && dm_motor.isConnected(YAW_ID, 0x01)
            && dm_motor.isConnected(PITCH_ID, 0x02))
        {
            yaw_offset = dm_motor.getAddAngleRad(YAW_ID);
            pitch_offset = dm_motor.getAngleRad(PITCH_ID);
            target_yaw_rad = 0.0f;
            target_pitch_rad = 0.0f;
            encoder_initialized = true;
        }
    });
}

void StartUARTReceive()
{
    auto &uart3 = HAL::UART::get_uart_bus_instance().get_device(HAL::UART::UartDeviceId::HAL_Uart3);
    HAL::UART::Data data{dbus_rx_buffer, DBUS_BUF_SIZE};
    uart3.receive_dma_idle(data);
    __HAL_DMA_DISABLE_IT(uart3.get_handle()->hdmarx, DMA_IT_HT);
}

void EnableMotors()
{
    dm_motor.On(YAW_ID, BSP::Motor::DM::Model::MIT);
    dm_motor.On(PITCH_ID, BSP::Motor::DM::Model::MIT);
    dm_motor.ClearErr(YAW_ID, BSP::Motor::DM::Model::MIT);
    dm_motor.ClearErr(PITCH_ID, BSP::Motor::DM::Model::MIT);
    motors_enabled = true;
}

void DisableMotors()
{
    dm_motor.Off(YAW_ID, BSP::Motor::DM::Model::MIT);
    dm_motor.Off(PITCH_ID, BSP::Motor::DM::Model::MIT);
    motors_enabled = false;
}

void Update()
{
    if (!motors_enabled || !encoder_initialized)
        return;

    target_yaw_rad += dr16.get_right_x() * YAW_SENSITIVITY;
    target_pitch_rad += dr16.get_right_y() * PITCH_SENSITIVITY;
    target_pitch_rad = Clamp(target_pitch_rad, PITCH_ANGLE_MIN, PITCH_ANGLE_MAX);

    float yaw_angle = dm_motor.getAddAngleRad(YAW_ID) - yaw_offset;
    float yaw_speed_target = yaw_angle_pid.UpDate(target_yaw_rad, yaw_angle);
    float yaw_speed = dm_motor.getVelocityRads(YAW_ID);
    float yaw_torque = yaw_speed_pid.UpDate(yaw_speed_target, yaw_speed);
    yaw_torque = Clamp(yaw_torque, -3.0f, 3.0f);
    dm_motor.ctrl_Mit(YAW_ID, 0.0f, 0.0f, 0.0f, 0.0f, yaw_torque);

    float pitch_angle = dm_motor.getAngleRad(PITCH_ID) - pitch_offset;
    float pitch_speed_target = pitch_angle_pid.UpDate(target_pitch_rad, pitch_angle);
    float pitch_speed = dm_motor.getVelocityRads(PITCH_ID);
    float pitch_torque = pitch_speed_pid.UpDate(pitch_speed_target, pitch_speed);
    pitch_torque = Clamp(pitch_torque, -3.0f, 3.0f);
    dm_motor.ctrl_Mit(PITCH_ID, 0.0f, 0.0f, 0.0f, 0.0f, pitch_torque);
}

void ProcessUARTRx(UART_HandleTypeDef *huart, uint16_t size)
{
    if (huart->Instance == USART3)
    {
        if (size == 18)
            dr16.parseData(dbus_rx_buffer);

        auto &uart3 = HAL::UART::get_uart_bus_instance().get_device(HAL::UART::UartDeviceId::HAL_Uart3);
        HAL::UART::Data data{dbus_rx_buffer, DBUS_BUF_SIZE};
        uart3.receive_dma_idle(data);
        __HAL_DMA_DISABLE_IT(huart->hdmarx, DMA_IT_HT);
    }
}

void ProcessCANRx(CAN_HandleTypeDef *hcan)
{
    if (hcan->Instance == CAN1)
    {
        HAL::CAN::ICanDevice &can1 = HAL::CAN::get_can_bus_instance().get_can1();
        HAL::CAN::Frame frame;
        while (can1.receive(frame)) {}
    }
}

}

extern "C" void Gimbal_Init(void)               { Gimbal::Init(); }
extern "C" void Gimbal_StartUARTReceive(void)    { Gimbal::StartUARTReceive(); }
extern "C" void Gimbal_EnableMotors(void)        { Gimbal::EnableMotors(); }
extern "C" void Gimbal_DisableMotors(void)       { Gimbal::DisableMotors(); }
extern "C" void Gimbal_Update(void)              { Gimbal::Update(); }
extern "C" void Gimbal_ProcessUARTRx(void *huart, uint16_t size) { Gimbal::ProcessUARTRx((UART_HandleTypeDef *)huart, size); }
extern "C" void Gimbal_ProcessCANRx(void *hcan)                  { Gimbal::ProcessCANRx((CAN_HandleTypeDef *)hcan); }
