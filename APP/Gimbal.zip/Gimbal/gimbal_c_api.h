#ifndef GIMBAL_C_API_H
#define GIMBAL_C_API_H

#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C"
{
#endif

    void Gimbal_Init(void);
    void Gimbal_StartUARTReceive(void);
    void Gimbal_EnableMotors(void);
    void Gimbal_DisableMotors(void);
    void Gimbal_Update(void);
    void Gimbal_ProcessUARTRx(void *huart, uint16_t size);
    void Gimbal_ProcessCANRx(void *hcan);

#ifdef __cplusplus
}
#endif

#endif
