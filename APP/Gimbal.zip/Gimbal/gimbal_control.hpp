#ifndef GIMBAL_CONTROL_HPP
#define GIMBAL_CONTROL_HPP

#pragma once

#include "DmMotor.hpp"
#include "DT7.hpp"
#include "pid.hpp"
#include "can_hal.hpp"
#include "uart_hal.hpp"

extern BSP::Motor::DM::J4310<2> dm_motor;
extern BSP::REMOTE_CONTROL::RemoteController dr16;

extern ALG::PID::PID yaw_angle_pid;
extern ALG::PID::PID pitch_angle_pid;
extern ALG::PID::PID yaw_speed_pid;
extern ALG::PID::PID pitch_speed_pid;

extern float target_yaw_rad;
extern float target_pitch_rad;

namespace Gimbal
{
    constexpr uint8_t YAW_ID = 1;
    constexpr uint8_t PITCH_ID = 2;

    constexpr float PITCH_ANGLE_MAX = 0.8f;
    constexpr float PITCH_ANGLE_MIN = -0.6f;

    constexpr float YAW_SENSITIVITY = 0.005f;
    constexpr float PITCH_SENSITIVITY = 0.003f;

    constexpr uint16_t DBUS_BUF_SIZE = 18;

    void Init();
    void StartUARTReceive();
    void EnableMotors();
    void DisableMotors();
    void Update();
    void ProcessUARTRx(UART_HandleTypeDef *huart, uint16_t size);
    void ProcessCANRx(CAN_HandleTypeDef *hcan);
}

#endif
